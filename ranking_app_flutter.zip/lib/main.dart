\
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const RankingApp());
}

class Person {
  String name;
  int points;

  Person({required this.name, required this.points});

  factory Person.fromJson(Map<String, dynamic> json) =>
      Person(name: json['name'], points: json['points']);

  Map<String, dynamic> toJson() => {'name': name, 'points': points};
}

class RankingApp extends StatelessWidget {
  const RankingApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'قائمة المراكز',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        // keep default font for simplicity
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final String storageKey = 'persons_list';
  List<Person> persons = [];
  final TextEditingController _searchCtl = TextEditingController();
  bool selectionMode = false;
  final Set<String> selectedNames = {};

  @override
  void initState() {
    super.initState();
    _loadPersons();
    _searchCtl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  Future<void> _loadPersons() async {
    final sp = await SharedPreferences.getInstance();
    final jsonStr = sp.getString(storageKey);
    if (jsonStr != null) {
      final List<dynamic> decoded = json.decode(jsonStr);
      setState(() {
        persons = decoded.map((e) => Person.fromJson(e)).toList();
      });
    }
  }

  Future<void> _savePersons() async {
    final sp = await SharedPreferences.getInstance();
    final encoded = json.encode(persons.map((p) => p.toJson()).toList());
    await sp.setString(storageKey, encoded);
  }

  void _persistAndRefresh() {
    setState(() {});
    _savePersons();
  }

  bool _nameExists(String name, {String? exceptName}) {
    final n = name.trim().toLowerCase();
    return persons.any((p) =>
        p.name.trim().toLowerCase() == n &&
        (exceptName == null ||
            p.name.trim().toLowerCase() != exceptName.trim().toLowerCase()));
  }

  List<Person> get _filtered {
    final q = _searchCtl.text.trim().toLowerCase();
    if (q.isEmpty) return List.from(persons);
    return persons.where((p) => p.name.toLowerCase().contains(q)).toList();
  }

  List<MapEntry<Person, int>> _computeRanks(List<Person> list) {
    List<Person> sorted = List.from(list);
    sorted.sort((a, b) {
      final cmp = b.points.compareTo(a.points);
      if (cmp != 0) return cmp;
      return a.name.compareTo(b.name);
    });

    List<MapEntry<Person, int>> result = [];
    int i = 0;
    int nextRank = 1;
    while (i < sorted.length) {
      int j = i + 1;
      while (j < sorted.length && sorted[j].points == sorted[i].points) {
        j++;
      }
      int groupLen = j - i;
      for (int k = i; k < j; k++) {
        result.add(MapEntry(sorted[k], nextRank));
      }
      nextRank += groupLen;
      i = j;
    }
    return result;
  }

  void _addPersonAction() {
    final nameCtl = TextEditingController();
    final pointsCtl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('إضافة اسم جديد'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtl,
                decoration: const InputDecoration(labelText: 'الاسم'),
                maxLines: 2,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: pointsCtl,
                decoration: const InputDecoration(labelText: 'النقاط'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () {
                final name = nameCtl.text.trim();
                final pts = int.tryParse(pointsCtl.text.trim()) ?? 0;
                if (name.isEmpty) return;
                if (_nameExists(name)) {
                  // show alert that name exists
                  showDialog(
                      context: context,
                      builder: (_) => Directionality(
                            textDirection: TextDirection.rtl,
                            child: AlertDialog(
                              title: const Text('تنبيه'),
                              content: Text('الاسم \"$name\" موجود مسبقًا، لا يمكن إضافته مرة أخرى.'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))
                              ],
                            ),
                          ));
                  return;
                }
                persons.add(Person(name: name, points: pts));
                _persistAndRefresh();
                Navigator.pop(context);
              },
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    );
  }

  void _addPointsDialog(Person p) {
    final ctl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text('إضافة نقاط إلى: ${p.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('النقاط الحالية: ${p.points}'),
              const SizedBox(height: 8),
              TextField(controller: ctl, decoration: const InputDecoration(labelText: 'نقاط تُضاف'), keyboardType: TextInputType.number),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () {
                final add = int.tryParse(ctl.text.trim()) ?? 0;
                p.points += add;
                _persistAndRefresh();
                Navigator.pop(context);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  void _editDialog(Person p) {
    final nameCtl = TextEditingController(text: p.name);
    final ptsCtl = TextEditingController(text: p.points.toString());
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تعديل'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtl, decoration: const InputDecoration(labelText: 'الاسم'), maxLines: 2),
              const SizedBox(height: 8),
              TextField(controller: ptsCtl, decoration: const InputDecoration(labelText: 'النقاط'), keyboardType: TextInputType.number),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () {
                final newName = nameCtl.text.trim();
                final newPts = int.tryParse(ptsCtl.text.trim()) ?? p.points;
                if (newName.isEmpty) return;
                if (newName.toLowerCase() != p.name.toLowerCase() && _nameExists(newName)) {
                  // show snackbar
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الاسم موجود مسبقًا'), behavior: SnackBarBehavior.floating));
                  return;
                }
                p.name = newName;
                p.points = newPts;
                _persistAndRefresh();
                Navigator.pop(context);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(Person p) {
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تأكيد الحذف'),
          content: Text('هل أنت متأكد من حذف \"${p.name}\"؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () {
                persons.removeWhere((x) => x.name == p.name && x.points == p.points);
                _persistAndRefresh();
                Navigator.pop(context);
              },
              child: const Text('نعم، حذف'),
            ),
          ],
        ),
      ),
    );
  }

  void _longPressOptions(Person p) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(leading: const Icon(Icons.edit), title: const Text('تعديل'), onTap: () { Navigator.pop(context); _editDialog(p); }),
              ListTile(leading: const Icon(Icons.delete), title: const Text('حذف'), onTap: () { Navigator.pop(context); _confirmDelete(p); }),
              ListTile(leading: const Icon(Icons.select_all), title: const Text('تحديد الكل'), onTap: () {
                Navigator.pop(context);
                setState(() {
                  selectionMode = true;
                  selectedNames.clear();
                  for (var x in persons) selectedNames.add(x.name);
                });
              }),
            ],
          ),
        ),
      ),
    );
  }

  void _toggleSelect(String name) {
    setState(() {
      if (selectedNames.contains(name)) selectedNames.remove(name);
      else selectedNames.add(name);
      if (selectedNames.isEmpty) selectionMode = false;
      else selectionMode = true;
    });
  }

  void _deleteSelectedConfirm() {
    showDialog(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('حذف المحدد'),
          content: const Text('هل تريد حذف كل العناصر المحددة؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () {
                persons.removeWhere((p) => selectedNames.contains(p.name));
                selectedNames.clear();
                selectionMode = false;
                _persistAndRefresh();
                Navigator.pop(context);
              },
              child: const Text('نعم، حذف'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    final ranked = _computeRanks(filtered);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: selectionMode ? Text('${selectedNames.length} محدد') : const Text('قائمة المراكز'),
          centerTitle: true,
          actions: [
            if (selectionMode)
              IconButton(
                icon: const Icon(Icons.delete_forever),
                onPressed: _deleteSelectedConfirm,
              ),
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () {
                // placeholder for share
              },
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: _addPersonAction,
          child: const Icon(Icons.add),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 10),
          child: Column(
            children: [
              // search bar separate from table
              TextField(
                controller: _searchCtl,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'ابحث بالاسم...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                  contentPadding: const EdgeInsets.symmetric(vertical: 6),
                ),
              ),
              const SizedBox(height: 12),
              // headers fixed
              Container(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: const [
                    Expanded(flex: 1, child: Center(child: Text('المركز', style: TextStyle(fontWeight: FontWeight.bold)))),
                    Expanded(flex: 3, child: Center(child: Text('الاسم', style: TextStyle(fontWeight: FontWeight.bold)))),
                    Expanded(flex: 2, child: Center(child: Text('النقاط', style: TextStyle(fontWeight: FontWeight.bold)))),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Expanded(
                child: ranked.isEmpty
                    ? const Center(child: Text('لا يوجد سجلات بعد. اضغط زر الإضافة لإضافة اسم.'))
                    : ListView.builder(
                        itemCount: ranked.length,
                        itemBuilder: (context, idx) {
                          final entry = ranked[idx];
                          final person = entry.key;
                          final rank = entry.value;
                          final isSelected = selectedNames.contains(person.name);
                          return InkWell(
                            onTap: () {
                              if (selectionMode) {
                                _toggleSelect(person.name);
                                return;
                              }
                              // find the actual object reference in persons list and open add points
                              final orig = persons.firstWhere((p) => p.name == person.name && p.points == person.points, orElse: () => person);
                              _addPointsDialog(orig);
                            },
                            onLongPress: () {
                              _longPressOptions(person);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
                              color: isSelected ? Colors.blue.withOpacity(0.08) : null,
                              child: Row(
                                children: [
                                  Expanded(flex: 1, child: Center(child: Text(rank.toString(), style: const TextStyle(fontSize: 16)))),
                                  Expanded(flex: 3, child: Center(child: Text(person.name, style: const TextStyle(fontSize: 16)))),
                                  Expanded(flex: 2, child: Center(child: Text(person.points.toString(), style: const TextStyle(fontSize: 16)))),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
